  <nav class="navbar navbar-default navbar-fixed-top topnav alert-success" role="navigation">
            <div class="container topnav">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand topnav" href="index.php"><img src="img/league1.png" height="120%"></a>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">

                    	<li>
                            <a class="btn btn-block btn-default" href="index.php">Home</a>
                        </li>

                        <li>
                            <a class="btn btn-block btn-default" href="soloq.php">Solo Q Ladder</a>
                        </li>

                        <li>
                            <a class="btn btn-block btn-default" href="flex.php">Flex Ladder</a>
                        </li>

                        <li>
                            <a class="btn btn-block btn-default" href="https://euw.leagueoflegends.com/en/" target="iframe_go">League Website</a>
                        </li>
                        <li>
                            <a class="btn btn-block btn-default"  href="http://status.leagueoflegends.com/#euw" target="iframe_go">Server Status</a>
                        </li>
                        <li>
                            <a class="btn btn-block btn-default" href="https://web.facebook.com/groups/428660150542211/" target="_blank">Facebook Page</a>
                        </li>
                         <li>
                            <a class="btn btn-block btn-default" href="http://www.surrenderat20.net/" target="iframe_go">Latest News</a>
                        </li>

                         <li>
                            <a class="btn btn-block btn-default" href="ping.php" >Ping Test</a>
                        </li>

 <li>
                            <a class="btn btn-block btn-default" href="http://www.lolking.net/" target="iframe_go">LolKing</a>
                        </li>

                         <li>
                            <a class="btn btn-block btn-default" href="http://www.lolnexus.com/" target="iframe_go">Lolnexus</a>
                        </li>

                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container -->
        </nav>